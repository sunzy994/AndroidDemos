package cmcm.com.shortcutdemo;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.PermissionGroupInfo;
import android.content.pm.PermissionInfo;
import android.util.Log;

import java.lang.reflect.Method;
import java.util.List;

/**
 * Created by sunzy on 16-4-21.
 */
public class N5 {


}
